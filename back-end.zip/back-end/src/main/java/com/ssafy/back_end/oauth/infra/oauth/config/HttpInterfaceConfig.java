package com.ssafy.back_end.oauth.infra.oauth.config;

import com.ssafy.back_end.oauth.infra.oauth.github.client.GithubApiClient;
import com.ssafy.back_end.oauth.infra.oauth.google.client.GoogleApiClient;
import com.ssafy.back_end.oauth.infra.oauth.kakao.client.KakaoApiClient;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.support.WebClientAdapter;
import org.springframework.web.service.invoker.HttpServiceProxyFactory;

@Configuration
public class HttpInterfaceConfig {

    @Bean
    public KakaoApiClient kakaoApiClient() {
        return createHttpInterface(KakaoApiClient.class);
    }

    @Bean
    public GithubApiClient githubApiClient() { return createHttpInterface(GithubApiClient.class); }

    @Bean
    public GoogleApiClient googleApiClient() { return createHttpInterface(GoogleApiClient.class); }


    private <T> T createHttpInterface(Class<T> clazz) {
        WebClient webClient = WebClient.create();
        HttpServiceProxyFactory build = HttpServiceProxyFactory
                .builder(WebClientAdapter.forClient(webClient)).build();
        return build.createClient(clazz);
    }
}